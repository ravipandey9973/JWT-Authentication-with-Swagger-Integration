﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Threading.Tasks;
using Authenticate.Models;
using System.Net;
using System.Text;
using Microsoft.AspNetCore.Authorization;


namespace Authenticate.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class DepartmentController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public DepartmentController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult GetDepartments()
        {
            try
            {
                string query = @"SELECT Id, DepartmentName FROM dbo.Dept";
                DataTable dt = new DataTable();
                string sqlDataSource = _configuration.GetConnectionString("dash");

                using (var con = new SqlConnection(sqlDataSource))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    da.Fill(dt);
                }

                // Check if DataTable is populated with data
                if (dt.Rows.Count == 0)
                {
                    return NotFound(); // Or return appropriate HTTP status code
                }

                // Convert DataTable to list of Department objects
                var departments = new List<Department>();
                foreach (DataRow row in dt.Rows)
                {
                    departments.Add(new Department
                    {
                        Id = Convert.ToInt32(row["Id"]),
                        DepartmentName = Convert.ToString(row["DepartmentName"])
                    });
                }

                return Ok(departments);
            }
            catch (Exception ex)
            {
                // Log the exception details
                _logger.LogError(ex, "An error occurred while fetching departments.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Failed to retrieve departments. See logs for details.");
            }
        }



        [HttpPost]
        public async Task<ActionResult> Post(Department dept)
        {
            try
            {
                string query = @"INSERT INTO dbo.Dept (DepartmentName) VALUES (@DepartmentName)";
                string sqlDataSource = _configuration.GetConnectionString("dash");
                using (var con = new SqlConnection(sqlDataSource))
                using (var cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@DepartmentName", dept.DepartmentName);
                    await con.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();
                }
                return Ok("Successfully Added");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Failed to Add: " + ex.Message);
            }
        }

        // Update an existing department
        [HttpPut]
        public async Task<ActionResult> Put(Department dept)
        {
            try
            {
                string query = @"UPDATE dbo.Dept SET DepartmentName = @DepartmentName WHERE Id = @Id";
                string sqlDataSource = _configuration.GetConnectionString("dash");
                using (var con = new SqlConnection(sqlDataSource))
                using (var cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Id", dept.Id);
                    cmd.Parameters.AddWithValue("@DepartmentName", dept.DepartmentName);
                    await con.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();
                }
                return Ok("Successfully Updated");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Failed to Update: " + ex.Message);
            }
        }

        // Delete a department
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            try
            {
                string query = @"DELETE FROM dbo.Dept WHERE Id = @Id";
                string sqlDataSource = _configuration.GetConnectionString("dash");
                using (var con = new SqlConnection(sqlDataSource))
                using (var cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Id", id);
                    await con.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();
                }
                return Ok("Successfully Deleted");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Failed to Delete: " + ex.Message);
            }
        }

        private class _logger
        {
            internal static void LogError(Exception ex, string v)
            {
                throw new NotImplementedException();
            }
        }
    }
}
