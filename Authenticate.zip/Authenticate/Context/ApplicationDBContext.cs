﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Authenticate.Models;

namespace Authenticate.Context
{
    public class ApplicationDBContext:DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext>options) :base(options)
        { 
        
        
        }
       
    public virtual  DbSet<User> UserInfo {  get; set; } 
    public  DbSet<Department>Dept { get; set; }
       
    }
}
